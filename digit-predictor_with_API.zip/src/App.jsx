import React, { useState } from "react";

// --- API credentials directly placed ---
const API_TOKEN = "KBZ28EV3NgJI2sX";
const APP_ID = "100454";

const symbolMap = {
  "Volatility 10 Index": "R_10",
  "Volatility 15 Index": "R_15",
  "Volatility 25 Index": "R_25",
  "Volatility 50 Index": "R_50",
  "Volatility 75 Index": "R_75",
  "Volatility 100 Index": "R_100",
  "Volatility 10 (1s) Index": "R_10_1S",
  "Volatility 15 (1s) Index": "R_15_1S",
  "Volatility 25 (1s) Index": "R_25_1S",
  "Volatility 50 (1s) Index": "R_50_1S",
  "Volatility 75 (1s) Index": "R_75_1S",
  "Volatility 100 (1s) Index": "R_100_1S",
};

export default function App() {
  const [symbol, setSymbol] = useState("R_10");
  const [prediction, setPrediction] = useState(null);
  const [connected, setConnected] = useState(false);

  let ws;

  const connectAPI = () => {
    ws = new WebSocket(`wss://ws.derivws.com/websockets/v3?app_id=${APP_ID}`);
    ws.onopen = () => {
      setConnected(true);
      console.log("✅ Connected to Deriv API");
    };

    ws.onmessage = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.msg_type === "tick") {
        const lastDigit = Number(data.tick.quote.toString().slice(-1));
        console.log("Last digit:", lastDigit);

        // --- STRATEGY PLACEHOLDER ---
        if (lastDigit >= 7) {
          setPrediction("Likely Match: Digit Under 7 in next 5–10s");
        } else {
          setPrediction("Likely Match: Digit Over 6 in next 5–10s");
        }
      }
    };
  };

  const startPrediction = () => {
    if (!connected) connectAPI();
    ws.send(JSON.stringify({ ticks: symbolMap[symbol], subscribe: 1 }));
  };

  return (
    <div style={{ fontFamily: "Arial", textAlign: "center", padding: "20px" }}>
      <h1>🚀 G2G Digit Predictor</h1>
      <p>Select an index to predict the next digit:</p>
      <select value={symbol} onChange={(e) => setSymbol(e.target.value)}>
        {Object.entries(symbolMap).map(([label, value]) => (
          <option key={value} value={value}>{label}</option>
        ))}
      </select>
      <br /><br />
      <button onClick={startPrediction} style={{ padding: "10px 20px", fontSize: "16px" }}>
        Predict
      </button>
      <div style={{ marginTop: "30px", fontSize: "18px" }}>
        {prediction && <p><strong>{prediction}</strong></p>}
      </div>
      <p style={{ marginTop: "50px", fontSize: "12px", color: "#555" }}>
        Connected: {connected ? "✅ Yes" : "❌ No"}
      </p>
    </div>
  );
}
